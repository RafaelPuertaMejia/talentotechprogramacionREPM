<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include '../../controllers/AlumnoController.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$alumnoController = new AlumnoController();

// Obtener los proyectos del alumno
$proyectos = $alumnoController->getProyectos($_SESSION['user']['id']);

// Verificar si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigo_proyecto = $_POST['codigo_proyecto'];
    $url_video = $_POST['url_video'];
    // Validar la URL
    if (filter_var($url_video, FILTER_VALIDATE_URL)) {
        // Insertar o actualizar en la base de datos
        $resultado = $alumnoController->guardarUrlVideo($codigo_proyecto, $url_video);
        if ($resultado) {
            $_SESSION['message'] = 'URL del video guardada exitosamente para el proyecto.';
        } else {
            $_SESSION['message'] = 'Error al guardar la URL del video.';
        }
    } else {
        $_SESSION['message'] = 'URL no válida.';
    }
    header('Location: subirVideoPI.php');
    exit;
}
?>

    <div class="container mt-auto">
        <h2 class="text-center">Subir URL del Video del Proyecto</h2>
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-info">
                <?php echo $_SESSION['message']; ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <?php if (count($proyectos) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Nombre del proyecto</th>
                        <th>URL del video</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($proyectos as $proyecto): ?>
                        <?php
                        $codigo_proyecto = $proyecto['codigo_proyecto'];
                        $url_video_actual = $alumnoController->getUrlVideo($codigo_proyecto);
                        ?>
                        <tr>
                            <td><?php echo $proyecto['nombre_proyecto']; ?></td>
                            <td><?php echo $url_video_actual ? $url_video_actual : 'No establecido'; ?></td>
                            <td>
                                <form action="subirVideoPI.php" method="post">
                                    <div class="form-group">
                                        <input type="text" name="url_video" class="form-control" required placeholder="Ingrese la URL de YouTube" value="<?php echo $url_video_actual ? $url_video_actual : ''; ?>">
                                    </div>
                                    <input type="hidden" name="codigo_proyecto" value="<?php echo $codigo_proyecto; ?>">
                                    <button type="submit" class="btn btn-primary">Guardar URL del Video</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No tienes proyectos asignados.</p>
        <?php endif; ?>
    </div>
</body>
</html>

