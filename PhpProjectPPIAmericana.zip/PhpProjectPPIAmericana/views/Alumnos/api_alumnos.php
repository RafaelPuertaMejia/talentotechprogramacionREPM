<?php
session_start();

// Verificar si el usuario ha iniciado sesión y si es un alumno
if (!isset($_SESSION['user']) || $_SESSION['user_role'] !== 'alumno') {
    echo json_encode(['status' => 'error', 'message' => 'No autorizado.']);
    exit();
}

// Incluir el controlador y archivos de configuración
require_once __DIR__ . '/../config/path.php';
require_once CONTROLLERS_PATH . 'AlumnosController.php';

// Crear instancia del controlador
$Alumnos = new AlumnosController();

// Obtener los datos de la solicitud AJAX
$action = $_POST['action'] ?? null;
$codigo_proyecto = $_POST['codigo_proyecto'] ?? null;

if (!$action || !$codigo_proyecto) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos.']);
    exit();
}

switch ($action) {
    case 'upload_video':
        $url_video = $_POST['url_video'] ?? '';
        if (filter_var($url_video, FILTER_VALIDATE_URL)) {
            $resultado = $Alumnos->updateUrlVideo($codigo_proyecto, $url_video);
            if ($resultado) {
                echo json_encode(['status' => 'success', 'message' => 'URL del video guardada exitosamente.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al guardar la URL del video.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'URL del video no es válida.']);
        }
        break;

    case 'upload_documento':
        $url_documento = $_POST['url_documento'] ?? '';
        if (filter_var($url_documento, FILTER_VALIDATE_URL)) {
            $resultado = $Alumnos->updateUrlDocumento($codigo_proyecto, $url_documento);
            if ($resultado) {
                echo json_encode(['status' => 'success', 'message' => 'URL del documento guardada exitosamente.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al guardar la URL del documento.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'URL del documento no es válida.']);
        }
        break;

    case 'upload_presentacion':
        $url_presentacion = $_POST['url_presentacion'] ?? '';
        if (filter_var($url_presentacion, FILTER_VALIDATE_URL)) {
            $resultado = $Alumnos->updateUrlPresentacion($codigo_proyecto, $url_presentacion);
            if ($resultado) {
                echo json_encode(['status' => 'success', 'message' => 'URL de la presentación guardada exitosamente.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al guardar la URL de la presentación.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'URL de la presentación no es válida.']);
        }
        break;

    default:
        echo json_encode(['status' => 'error', 'message' => 'Acción no válida.']);
        break;
}

