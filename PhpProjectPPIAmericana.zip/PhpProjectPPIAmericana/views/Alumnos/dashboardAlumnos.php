<?php
// Verificar que la sesión esté iniciada y que el usuario tenga el rol correcto para acceder a este dashboard
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Registrar el estado actual de la sesión para depuración
error_log("Estado de la sesión en dashboardAlumnos.php: " . json_encode($_SESSION));

// Incluir el archivo necesario para definir rutas
require_once __DIR__ . '/../../config/path.php';

// Definir PUBLIC_PATH si no está definido
if (!defined('PUBLIC_PATH')) {
    define('PUBLIC_PATH', __DIR__ . '/../../public/');
    error_log("PUBLIC_PATH no estaba definido. Se ha definido con el valor: " . PUBLIC_PATH);
}

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'alumno') {
    // Limpiar cualquier mensaje de error previo
    if (isset($_SESSION['error_message'])) {
        unset($_SESSION['error_message']);
    }
    $_SESSION['error_message'] = 'Acceso no autorizado.';
    header('Location: ' . VIEWS_URL . 'auth/login.php?error=' . urlencode($_SESSION['error_message']));
    exit();
}

// Asegurarse de que la última actividad de la sesión no haya excedido el tiempo de inactividad permitido
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) { // 1800 segundos = 30 minutos
    // Tiempo de inactividad excedido, cerrar la sesión
    session_unset();
    session_destroy();
    $_SESSION['error_message'] = 'La sesión ha expirado. Por favor, inicia sesión nuevamente.';
    header('Location: ' . VIEWS_URL . 'auth/login.php?error=' . urlencode($_SESSION['error_message']));
    exit();
} else {
    // Actualizar la última actividad
    $_SESSION['last_activity'] = time();
}

// Inicializar las variables necesarias
$data = isset($data) ? $data : [];
$codigo_proyecto = isset($codigo_proyecto) ? $codigo_proyecto : null;

// Incluir los archivos de navegación y barra lateral
include_once(PUBLIC_PATH . 'inc/nav.php');
include_once(PUBLIC_PATH . 'inc/sidebar_lateral_alumnos.php');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Dashboard Alumnos Proyecto PPI Americana</title>
    <link rel="stylesheet" href="../../public/css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
</head>
<body class="sb-nav-fixed">
    <?php
    // Incluir el menú de navegación y la barra lateral con rutas absolutas
    include_once(__DIR__ . "/../../public/inc/nav.php");
    include_once(__DIR__ . "/../../public/inc/sidebar_lateral_alumnos.php");
    ?>
    <div id="layoutSidenav_content">
        <main>
            <!-- Mostrar el nombre del alumno desde la sesión -->
            <img src="../../img/logo1.png" alt="" width="800" height="80" class="d-inline-block align-top">
            <h2 class="mt-4">Bienvenido, <?php echo htmlspecialchars($_SESSION['user_name'], ENT_QUOTES, 'UTF-8'); ?></h2>

            <div class="container-fluid px-4">
                <div style="width: 100%; max-width: 960px;">
                    <h1 class="mt-4">Dashboard</h1>
                    <!-- Mostrar mensaje si existe -->
                    <?php if (isset($_SESSION['message'])): ?>
                        <div class="alert alert-info">
                            <?php echo htmlspecialchars($_SESSION['message'], ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                        <?php unset($_SESSION['message']); ?>
                    <?php endif; ?>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">
                            <table class="table table-striped table-bordered table-hover mx-5 container-flex" style="align-content: center; align-items:center">
                                <thead>
                                    <tr>
                                        <th>Código del Proyecto</th>
                                        <th>Nombre del Proyecto</th>
                                        <th>Integrantes</th>
                                        <th>Semestre</th>
                                        <th>Docente Asesor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Mostrar los proyectos si existen
                                    if (!empty($data)) {
                                        foreach ($data as $fila) {
                                            $Alumno = isset($Alumnos) ? $Alumnos->NameAlumnos($fila['codigo_proyecto']) : [];
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($fila['codigo_proyecto'], ENT_QUOTES, 'UTF-8') . "</td>";
                                            echo "<td>" . htmlspecialchars($fila['nombre_proyecto'], ENT_QUOTES, 'UTF-8') . "</td>";
                                            echo "<td>";
                                            if (!empty($Alumno)) {
                                                foreach ($Alumno as $alumno) {
                                                    echo htmlspecialchars($alumno['integrante'], ENT_QUOTES, 'UTF-8') . "<br>";
                                                }
                                            } else {
                                                echo "Sin Integrantes";
                                            }
                                            echo "</td>";
                                            echo "<td>" . htmlspecialchars($fila['semestre_proyecto'], ENT_QUOTES, 'UTF-8') . "</td>";
                                            echo "<td>" . htmlspecialchars($fila['docente_asesor'], ENT_QUOTES, 'UTF-8') . "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='5' class='text-center'>No se encontraron proyectos asociados al alumno.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </li>
                    </ol>
                </div>
                <div class="container-fluid px-4">
                    <div class="col-md-9">
                        <h1>Bienvenido al Panel del Alumno</h1>
                        <p>Seleccione una opción para comenzar:</p>
                        <!-- Botones para subir URLs -->
                        <?php if (!is_null($codigo_proyecto) && $codigo_proyecto): ?>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalVideo">
                                Subir Video
                            </button>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalDocumento">
                                Subir Documento
                            </button>
                            <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modalPresentacion">
                                Subir Presentación
                            </button>
                        <?php else: ?>
                            <p>No puedes subir documentos porque no tienes proyectos asignados.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
        <br><br><br><br>
    </div>
    <?php include PUBLIC_PATH.'inc/footer.php'; ?>
        <!-- Modales -->
        <?php if ($codigo_proyecto): ?>
            <!-- Modal para subir Video -->
            <div class="modal fade" id="modalVideo" tabindex="-1" role="dialog" aria-labelledby="modalVideoLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form action="dashboardAlumnos.php" method="post">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Subir URL del Video</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">

                                <div class="form-group">
                                    <label for="url_video">URL del Video (YouTube)</label>
                                    <input type="url" class="form-control" id="url_video" name="url_video" placeholder="Ingrese la URL del video" required>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <input type="hidden" name="action" value="upload_video">
                                <input type="hidden" name="codigo_proyecto" value="<?php echo htmlspecialchars($codigo_proyecto, ENT_QUOTES, 'UTF-8'); ?>">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Modal para subir Documento -->
            <div class="modal fade" id="modalDocumento" tabindex="-1" role="dialog" aria-labelledby="modalDocumentoLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form action="dashboardAlumnos.php" method="post">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Subir URL del Documento</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">

                                <div class="form-group">
                                    <label for="url_documento">URL del Documento (PDF o DOCX)</label>
                                    <input type="url" class="form-control" id="url_documento" name="url_documento" placeholder="Ingrese la URL del documento" required>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <input type="hidden" name="action" value="upload_documento">
                                <input type="hidden" name="codigo_proyecto" value="<?php echo htmlspecialchars($codigo_proyecto, ENT_QUOTES, 'UTF-8'); ?>">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Modal para subir Presentación -->
            <div class="modal fade" id="modalPresentacion" tabindex="-1" role="dialog" aria-labelledby="modalPresentacionLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form action="dashboardAlumnos.php" method="post">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Subir URL de la Presentación</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">

                                <div class="form-group">
                                    <label for="url_presentacion">URL de la Presentación (PowerPoint)</label>
                                    <input type="url" class="form-control" id="url_presentacion" name="url_presentacion" placeholder="Ingrese la URL de la presentación" required>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <input type="hidden" name="action" value="upload_presentacion">
                                <input type="hidden" name="codigo_proyecto" value="<?php echo htmlspecialchars($codigo_proyecto, ENT_QUOTES, 'UTF-8'); ?>">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <!-- Scripts de Bootstrap y jQuery -->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>