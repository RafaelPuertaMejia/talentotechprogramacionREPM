<!DOCTYPE html>
<html lang="es">
<?php
// Iniciar la sesión si no se ha iniciado previamente
if (session_status() == PHP_SESSION_NONE) {
    if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
}

// Registrar el estado de la sesión para depuración
error_log("Estado de la sesión al iniciar login.php: " . json_encode($_SESSION));

// Incluir el archivo necesario para definir rutas
require_once __DIR__ . '/../../config/path.php';

// Verificar si PUBLIC_PATH está definido
if (!defined('PUBLIC_PATH')) {
    error_log("Error: PUBLIC_PATH no está definido. Asegúrate de que el archivo de configuración se incluye correctamente.");
    die("Error crítico: No se pudo definir la ruta pública.");
}
// Incluir el header del proyecto
include_once(PUBLIC_PATH . 'inc/header.php');

// Limpiar cualquier mensaje de error previo si estamos cargando la página de nuevo
if (isset($_SESSION['error_message'])) {
    error_log("Limpiando mensaje de error previo: " . $_SESSION['error_message']);
    unset($_SESSION['error_message']);
}

// Procesar el formulario de inicio de sesión cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Limpiar entradas del usuario
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = htmlspecialchars($_POST['password'], ENT_QUOTES, 'UTF-8');

    // Registrar intento de inicio de sesión
    error_log("Intento de inicio de sesión con email: " . $email);

    // Incluir el archivo necesario para el controlador de autenticación
    require_once CONFIG_PATH . 'database.php';
    require_once CONTROLLERS_PATH . 'AuthController.php';

// Evitar múltiples llamadas a session_start() en el controlador
error_log("Verificando si la sesión ya está activa antes de iniciar autenticación");
   

    // Registrar el estado de la sesión antes de iniciar el proceso de autenticación
    error_log("Estado de la sesión antes de autenticación: " . json_encode($_SESSION));

    // Crear instancia de la base de datos y del controlador de autenticación
    $database = new Database();
    $db = $database->getConnection();
    $authController = new AuthController($db);

    // Ejecutar el método login del controlador
// Registrar estado de la sesión antes de login
error_log("Estado de la sesión antes de login en AuthController: " . json_encode($_SESSION));
    $authController->login($email, $password);

    // Si se produjo un error, registrar en el log
    if (isset($_SESSION['error_message'])) {
        error_log("Error durante la autenticación: " . $_SESSION['error_message']);
    } else {
        error_log("Inicio de sesión exitoso para el usuario: " . $email);
    }
}

// Mostrar el mensaje de error si existe
$error = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';
if ($error) {
    unset($_SESSION['error_message']);  // Limpiar el mensaje de error después de mostrarlo
    error_log("Mensaje de error mostrado y limpiado.");
}
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">Iniciar Sesión</div>
                <div class="card-body">
                    <!-- Mostrar mensaje de error si existe -->
                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <!-- Formulario de inicio de sesión -->
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="email">Correo Electrónico</label>
                            <input type="email" class="form-control" id="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8') : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Iniciar Sesión</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<?php
// Incluir el footer del proyecto si PUBLIC_PATH está definido
if (defined('PUBLIC_PATH')) {
    include_once(PUBLIC_PATH . 'inc/footer.php');
} else {
    error_log("No se pudo incluir el footer ya que PUBLIC_PATH no está definido.");
}
?>
</body>
</html>


