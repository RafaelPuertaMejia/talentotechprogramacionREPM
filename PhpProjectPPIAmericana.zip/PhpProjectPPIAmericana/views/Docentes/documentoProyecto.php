<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include '../../controllers/DocenteController.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$docenteController = new DocenteController();
$proyectos = $docenteController->getProyectos($_SESSION['user']['id']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documento del Proyecto</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-auto">
        <div class="row">
            <div class="col-md-3 small-font">
                <h4 class="text-center">Proyectos</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nombre del proyecto</th>
                            <th>URL del video</th>
                            <th>Evaluado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($proyectos as $proyecto): ?>
                            <tr>
                                <td><?php echo $proyecto['nombre_proyecto']; ?></td>
                                <td>
                                    <button class="view-document-button btn btn-link" data-url="<?php echo $proyecto['url_documento']; ?>">
                                        Ver documento
                                    </button>
                                </td>
                                <td><input type="checkbox" 
                                    <?php
                                    echo $docenteController->esEvaluado(
                                            $proyecto['codigo_proyecto']) ?
                                            'checked' : '';
                                    ?> disabled></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-9">
                <h2 class="text-center">Documento del Proyecto</h2>
                <div id="document-viewer"></div>

                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-info">
                        <?php echo $_SESSION['message']; ?>
                    </div>
                    <?php unset($_SESSION['message']); ?> <!-- Elimina el mensaje de la sesión después de mostrarlo -->
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal para mostrar el documento -->
    <div class="modal" id="document-modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Documento del Proyecto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <iframe id="document-iframe" src="" style="width:100%; height:600px;" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Manejador de clic para el botón de ver documento
            $('.view-document-button').click(function() {
                var documentUrl = $(this).data('url');
                $('#document-iframe').attr('src', 'https://docs.google.com/viewer?url=' + documentUrl + '&embedded=true');
                $('#document-modal').modal('show');
            });
        });
    </script>
</body>
</html>
