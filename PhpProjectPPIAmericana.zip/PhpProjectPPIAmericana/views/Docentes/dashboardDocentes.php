<?php
session_start();

// Depuración para verificar las variables de sesión
var_dump($_SESSION); // Muestra las variables de sesión actuales

// Verificar si el usuario ha iniciado sesión correctamente y tiene el rol de 'docente'
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'docente') {
    session_unset();
    session_destroy();

    // Redirigir al formulario de inicio de sesión si no está autenticado
    header('Location: ../auth/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Dashboard Docentes Proyecto PPI Americana</title>
    <link rel="stylesheet" href="../../public/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
</head>
<body class="sb-nav-fixed">
    <?php
    // Incluir el menú de navegación y la barra lateral con rutas absolutas
    include_once(__DIR__ . "/../../public/inc/nav.php");
    include_once(__DIR__ . "/../../public/inc/sidebar_lateral_docentes.php");
    ?>
    <div id="layoutSidenav_content">
        <main>
            <img src="../../img/logo1.png" alt="" width="800" height="80" class="d-inline-block align-top">
            <div class="container-fluid px-4">
                <h1 class="mt-4">Dashboard</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
                <section id="section-content">
                    <div class="col-md-9">
                        <h1>Bienvenido al Panel de Administrador</h1>
                        <p>Seleccione una opción del menú para comenzar.</p>
                    </div>
                    <div class="row">
                        <div class="col-xl-3 col-md-6">
                            <div class="card bg-primary text-white mb-4">
                                <div class="card-body">Evaluación Videos</div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <p>Aquí puedes evaluar video.</p>
                                    <a class="small text-white stretched-link" href="../../views/Docentes/videoProyecto.php"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card bg-warning text-bg-dark mb-4">
                                <div class="card-body">Evaluación Presentaciones(PPTs)</div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <p>Aquí puedes evaluar las presentaciones (PPTs).</p>
                                    <a class="small text-white stretched-link" href="../../models/AlumnosModels/subirPpts.php"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card bg-success text-white mb-4">
                                <div class="card-body">Evaluar Documento PPI</div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <p>Aquí puedes evaluar el documento del proyecto.</p>
                                    <a class="small text-white stretched-link" href="../../views/Docentes/documentoProyecto.php"></a>
                                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card bg-danger text-white mb-4">
                                <div class="card-body">Danger Card</div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">View Details</a>
                                    <div class="small text-white"><i class="fas"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </main>
        <?php include __DIR__ . '/../../public/inc/footer.php'; ?>
    </div>

    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../../public/js/ventanas.js"></script>
    <script>
    $(document).ready(function () {
        $('a.stretched-link').on('click', function (e) {
            e.preventDefault();
            var url = $(this).attr('href');
            $('#section-content').load(url);
        });
    });
    </script>
</body>
</html>
