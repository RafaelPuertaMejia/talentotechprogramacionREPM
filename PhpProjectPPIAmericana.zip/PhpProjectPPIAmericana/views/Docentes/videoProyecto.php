<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include '../../controllers/DocenteController.php';

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['user']) || !isset($_SESSION['user']['id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$docenteController = new DocenteController();
$proyectos = $docenteController->getProyectos($_SESSION['user']['id']);
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.bundle.min.js"></script>
<script src="../../public/js/loadVideo.js"></script>
<script src="../../public/js/envioNotaVideo.js"></script>

<div class="container mt-auto">
    <div class="row">
        <div class="col-md-3 small-font">
            <h4 class="text-center">Proyectos</h4>
            <table class="table">
                <thead>
                    <tr>
                        <th>Nombre del proyecto</th>
                        <th>URL del video</th>
                        <th>Evaluado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($proyectos as $proyecto): ?>
                        <tr>
                            <td><?php echo $proyecto['nombre_proyecto']; ?></td>
                            <td>
                                <button class="video-button" data-url="<?php echo $proyecto['url_video']; ?>"
                                        data-codigo="<?php echo $proyecto['codigo_proyecto']; ?>"
                                        data-semestre="<?php echo $proyecto['semestre']; ?>">
                                    Ver video
                                </button>
                            </td>
                            <td><input type="checkbox" 
                                <?php
                                echo $docenteController->esEvaluado(
                                        $proyecto['codigo_proyecto']) ?
                                        'checked' : '';
                                ?> disabled></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <h2 class="text-center">Video</h2>
            <div class="embed-responsive embed-responsive-16by9">
                <div id="player" class="embed-responsive-item"></div>
            </div>
           <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-info">
        <?php echo $_SESSION['message']; ?>
    </div>
    <?php unset($_SESSION['message']); ?> <!-- Elimina el mensaje de la sesión después de mostrarlo -->
<?php endif; ?>
        </div>
        <div class="col-md-3 small-font">  
            <h4 class="text-center mt-5">Rúbrica de evaluación</h4>
            <form action="../../controllers/DocenteController.php" method="post" class="p-3" onsubmit="return confirm('¿Estás seguro de que quieres enviar esta nota?');">
                <div class="form-group">
                    <label for="aspecto1">La duración del video es la adecuada:</label>
                    <select name="aspecto1" id="aspecto1" class="form-control">
                        <option value="cumple">Cumple</option>
                        <option value="nocumple" selected>No cumple</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="aspecto2">El video tiene introducción y conclusión:</label>
                    <select name="aspecto2" id="aspecto2" class="form-control">
                        <option value="cumple">Cumple</option>
                        <option value="nocumple" selected>No cumple</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="aspecto3">El video aborda todos los aspectos del proyecto:</label>
                    <select name="aspecto3" id="aspecto3" class="form-control">
                        <option value="cumple">Cumple</option>
                        <option value="nocumple" selected>No cumple</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="aspecto4">En el video se muestra el rol de cada integrante del equipo:</label>
                    <select name="aspecto4" id="aspecto4" class="form-control">
                        <option value="cumple">Cumple</option>
                        <option value="nocumple" selected>No cumple</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="aspecto5">El video tiene buena calidad visual y auditiva:</label>
                    <select name="aspecto5" id="aspecto5" class="form-control">
                        <option value="cumple">Cumple</option>
                        <option value="nocumple" selected>No cumple</option>
                    </select>
                </div>
                <input type="hidden" name="codProyDoc" id="codProyDoc">
                <input type="hidden" name="semestre" id="semestre">
                <button type="submit" class="btn btn-success mt-3">Enviar</button>
            </form>
        </div>
    </div>
</div>

<!-- JS de Bootstrap 5 -->







