
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="../css/style.css"></script>

<footer class="footer">
    <div class="container-fluid bg-dark text-white py-3">
        <div class="container">
            <div class="row">
                <div class="container text-center">
                    <h3>Medellín</h3>
                    <img loading="lazy" decoding="async" class="alignleft size-full wp-image-6257" src="https://americana.edu.co/medellin/wp-content/uploads/2018/10/Logo-coruniamericana_187x50_187x50.png" alt="" width="188" height="51">
                </div>

            </div>
        </div>
    </div>


    <div class="container-fluid bg-dark text-white py-3">
        <div class="container text-center">
            <p class="mb-0">Institución Universitaria Americana © Todos los derechos reservados. Medellín, Antioquia, Colombia.</p>
        </div>
    </div>
</footer>

<script>
    window.onbeforeunload = function () {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "../../controllers/logout.php", true);
        xhr.send();
    }
</script> <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="../js/sidebarToggle.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="../js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<script src="assets/demo/chart-area-demo.js"></script>
<script src="assets/demo/chart-bar-demo.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script src="js/datatables-simple-demo.js"></script>
</body>
</html>
