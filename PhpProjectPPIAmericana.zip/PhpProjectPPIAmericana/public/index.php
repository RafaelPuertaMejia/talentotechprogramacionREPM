<?php
// Redireccionar al usuario al formulario de inicio de sesión
header("Location: ../views/auth/login.php");
exit;
?>